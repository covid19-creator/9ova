(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_14269895._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_14269895._.js",
  "chunks": [
    "static/chunks/node_modules_1c53a440._.js",
    "static/chunks/src_511cd5de._.js"
  ],
  "source": "dynamic"
});
