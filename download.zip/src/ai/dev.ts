import { config } from 'dotenv';
config();

import '@/ai/flows/personalized-welcome-message.ts';
import '@/ai/flows/ai-powered-suggestions.ts';