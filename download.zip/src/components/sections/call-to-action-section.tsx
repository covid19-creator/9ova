import { CheckSquare } from "lucide-react";

export function CallToActionSection() {
  const currentYear = new Date().getFullYear();

  return (
    <section className="w-full py-16 md:py-24 lg:py-32 bg-[hsl(var(--cta-background))] text-[hsl(var(--cta-foreground))]">
      <div className="container max-w-[1440px] px-4 sm:px-6 md:px-8 lg:px-16 xl:px-20 text-center space-y-10">
        <div className="flex items-center justify-center gap-2 animate-in fade-in-0 zoom-in-75 duration-700">
          <CheckSquare className="h-8 w-8 md:h-10 md:w-10" />
          <span className="text-3xl md:text-4xl font-semibold">gostudios</span>
        </div>

        <h2 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight leading-tight animate-in fade-in-0 slide-in-from-bottom-5 duration-700 delay-200">
          Let's work together
        </h2>

        <a
          href="mailto:ranagaurav687@gmail.com"
          className="inline-block text-xl md:text-2xl font-medium hover:underline underline-offset-4 animate-in fade-in-0 slide-in-from-bottom-5 duration-700 delay-400"
        >
          ranagaurav687@gmail.com
        </a>

        <div className="pt-10 md:pt-16 animate-in fade-in-0 duration-700 delay-600">
          <p className="text-sm text-[hsl(var(--cta-foreground),0.8)]">
            © {currentYear} GoStudios. All rights reserved.
          </p>
          <p className="text-sm text-[hsl(var(--cta-foreground),0.8)]">
            Brought to you by <span className="font-semibold">timewarp</span>
          </p>
        </div>
      </div>
    </section>
  );
}
