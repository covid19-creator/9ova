import { Zap, PenTool, BarChartHorizontalBig, CircleDot, MessageSquareText, ClipboardCheck, Sparkles, Repeat, Send, Asterisk } from 'lucide-react';

const benefits = [
  {
    icon: Zap,
    title: 'Fast turnaround',
    description: 'We focus on one client at a time, delivering exceptional results fast, without compromising on quality.',
  },
  {
    icon: PenTool,
    title: 'Tailored design',
    description: 'We emphasise delivering unique designs, ensuring your brand stands out with a distinct visual identity.',
  },
  {
    icon: BarChartHorizontalBig,
    title: 'Scalable solutions',
    description: 'We can integrate new features, revamp content and adapt your project to follow the latest trends.',
  },
  {
    icon: CircleDot,
    title: 'Fixed price',
    description: 'Access a range of web services at a fixed price, making it easier to budget and control expenses.',
  },
];

const stats = [
  { value: '37+', label: 'Finalized projects' },
  { value: '94%', label: 'Conversion rate improvement' },
  { value: '12+', label: 'Years of experience' },
];

const services = [
  'Responsive Design',
  'User Interface',
  'User Experience',
  'Custom Code',
  'Component Libraries',
  'Desktop & Mobile Apps',
  'Website Migration',
  'Figma to Framer',
];

const fields = ['AI', 'SaaS', 'Fintech', 'E-Commerce', 'ESports', 'Automotive', 'Fashion', 'Real Estate'];

const approaches = [
  {
    icon: MessageSquareText,
    title: 'Consulting',
    description: "We're asking some questions to understand your goals, design preferences and target audience. This is the foundation settlement.",
  },
  {
    icon: ClipboardCheck,
    title: 'Collaborative review',
    description: 'During the design phase we invite the client to review and provide feedback. This allows a better structure and functionality early on.',
  },
  {
    icon: Sparkles,
    title: 'Make it pop',
    description: 'Establishing a structure focused on functionality and accessibility, including interactions that ensure total immersion.',
  },
  {
    icon: Repeat,
    title: 'Iterate',
    description: "Polishing the details is important when it comes to the final product. We're iterating until you're happy with the results.",
  },
];

export function BenefitsSection() {
  return (
    <section className="w-full py-16 md:py-24 lg:py-32 bg-background">
      <div className="container max-w-[1440px] px-4 sm:px-6 md:px-8 lg:px-16 xl:px-20 space-y-16">
        {/* Benefits Title */}
        <h2 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl animate-in fade-in-0 slide-in-from-bottom-2 duration-700">
          Benefits
        </h2>

        {/* Benefits Grid */}
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {benefits.map((benefit, index) => (
            <div 
              key={benefit.title} 
              className="flex flex-col items-start p-6 rounded-lg bg-muted shadow-sm animate-in fade-in-0 slide-in-from-bottom-5 duration-500"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <benefit.icon className="h-8 w-8 text-primary mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">{benefit.title}</h3>
              <p className="text-sm text-muted-foreground">{benefit.description}</p>
            </div>
          ))}
        </div>

        {/* Large Text Block */}
        <div className="text-center py-12 animate-in fade-in-0 duration-1000 delay-200">
          <p className="text-3xl md:text-4xl lg:text-5xl font-medium text-foreground/40 leading-normal">
            BUILDING WEBSITES THAT NOT ONLY LOOK GREAT BUT ALSO DELIVER MEASURABLE RESULTS.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-8 md:grid-cols-3 text-center">
          {stats.map((stat, index) => (
            <div 
              key={stat.label} 
              className="animate-in fade-in-0 slide-in-from-bottom-5 duration-500"
              style={{ animationDelay: `${index * 150 + 300}ms` }}
            >
              <p className="text-6xl md:text-7xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Services and Fields Section */}
        <div className="grid md:grid-cols-5 gap-12 items-start py-12 animate-in fade-in-0 duration-700 delay-400">
          <div className="md:col-span-3 space-y-3">
            {services.map((service) => (
              <p key={service} className="text-3xl font-medium text-foreground">
                {service}
              </p>
            ))}
          </div>
          <div className="md:col-span-2 p-8 rounded-xl bg-[hsl(84_100%_59%)] text-black relative shadow-lg">
            <Asterisk className="absolute top-6 right-6 h-8 w-8" />
            <h3 className="text-4xl font-bold mb-6">Fields</h3>
            <ul className="space-y-2">
              {fields.map((field) => (
                <li key={field} className="text-lg font-medium">
                  {field}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Approach Title */}
        <h2 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl pt-8 animate-in fade-in-0 slide-in-from-bottom-2 duration-700 delay-500">
          Approach
        </h2>

        {/* Approach Grid */}
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-2">
          {approaches.map((approach, index) => (
            <div 
              key={approach.title} 
              className="flex flex-col p-6 rounded-lg bg-muted shadow-sm animate-in fade-in-0 slide-in-from-bottom-5 duration-500"
              style={{ animationDelay: `${index * 100 + 600}ms` }}
            >
              <div className="flex items-center mb-3">
                <approach.icon className="h-6 w-6 text-primary mr-3" />
                <h3 className="text-xl font-semibold text-foreground">{approach.title}</h3>
              </div>
              <p className="text-sm text-muted-foreground">{approach.description}</p>
            </div>
          ))}
           <div 
             className="flex flex-col p-8 rounded-lg bg-[hsl(0_0%_21%)] text-primary-foreground shadow-lg md:col-span-2 animate-in fade-in-0 slide-in-from-bottom-5 duration-500"
             style={{ animationDelay: `${approaches.length * 100 + 600}ms` }}
            >
            <div className="flex items-center mb-4">
              <Send className="h-7 w-7 text-primary-foreground mr-3" />
              <h3 className="text-2xl font-bold">Ready to take off</h3>
            </div>
            <p className="text-sm text-primary-foreground/80">
              Handing off the fully working website or landing page which is ready to launch right away, empowering you with a seamless transition from concept to final product.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
}
