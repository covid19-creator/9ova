import Image from 'next/image';
import Link from 'next/link';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const projects = [
  {
    id: '1',
    title: 'Nebula Platform',
    description: 'A cutting-edge SaaS platform for cloud resource management and optimization, built with a focus on scalability and user experience.',
    imageUrl: 'https://placehold.co/800x600.png', // Updated placeholder size
    imageHint: 'cloud platform',
    projectUrl: '#',
  },
  {
    id: '2',
    title: 'QuantumLeap AI',
    description: 'An AI-driven analytics tool that provides deep insights from complex datasets, empowering businesses to make smarter decisions.',
    imageUrl: 'https://placehold.co/800x600.png', // Updated placeholder size
    imageHint: 'AI analytics',
    projectUrl: '#',
  },
  {
    id: '3',
    title: 'EcoShift Marketplace',
    description: 'An e-commerce platform connecting sustainable brands with conscious consumers, promoting eco-friendly products and practices.',
    imageUrl: 'https://placehold.co/800x600.png', // Updated placeholder size
    imageHint: 'ecommerce sustainable',
    projectUrl: '#',
  },
   {
    id: '4',
    title: 'Synergy CRM',
    description: 'A comprehensive Customer Relationship Management system designed for small to medium-sized enterprises to enhance client engagement.',
    imageUrl: 'https://placehold.co/800x600.png', // Updated placeholder size
    imageHint: 'CRM software',
    projectUrl: '#',
  },
  {
    id: '5',
    title: 'Nova VR Experience',
    description: 'An immersive virtual reality experience for architectural visualization, allowing clients to walk through designs before construction.',
    imageUrl: 'https://placehold.co/800x600.png', // Updated placeholder size
    imageHint: 'VR architecture',
    projectUrl: '#',
  },
  {
    id: '6',
    title: 'Helios Solar Monitoring',
    description: 'A web application for real-time monitoring and analytics of solar panel performance, optimizing energy generation.',
    imageUrl: 'https://placehold.co/800x600.png', // Updated placeholder size
    imageHint: 'solar energy',
    projectUrl: '#',
  },
];

export function ProjectShowcaseSection() {
  return (
    <section id="projects" className="w-full py-12 md:py-16 lg:py-20 bg-background">
      <div className="container max-w-[1440px] px-4 sm:px-6 md:px-8 lg:px-16 xl:px-20">
        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full max-w-4xl mx-auto animate-in fade-in-0 duration-1000"
        >
          <CarouselContent>
            {projects.map((project, index) => (
              <CarouselItem key={project.id} className="md:basis-1/1 lg:basis-1/1"> {/* Adjust basis for how many items to show */}
                <div className="p-1">
                  <Link href={project.projectUrl} passHref legacyBehavior>
                    <a target="_blank" rel="noopener noreferrer" className="block overflow-hidden rounded-lg group">
                      <Image
                        alt={project.title}
                        className="aspect-[4/3] w-full object-cover transition-transform duration-300 ease-in-out group-hover:scale-105"
                        height={600}
                        src={project.imageUrl}
                        data-ai-hint={project.imageHint}
                        width={800}
                      />
                    </a>
                  </Link>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="ml-12 hidden sm:flex"/>
          <CarouselNext className="mr-12 hidden sm:flex"/>
        </Carousel>
      </div>
    </section>
  );
}
