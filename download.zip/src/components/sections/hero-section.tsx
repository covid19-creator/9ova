import { Button } from '@/components/ui/button';
import Link from 'next/link';

export function HeroSection() {
  return (
    <section className="w-full py-20 md:py-28 lg:py-36 bg-background">
      <div className="container max-w-[1440px] px-4 sm:px-6 md:px-8 lg:px-16 xl:px-20">
        <div className="flex flex-col items-start space-y-10 max-w-3xl">
          <div className="space-y-4 animate-in fade-in-0 slide-in-from-bottom-4 duration-1000">
            <h1 className="text-5xl font-bold tracking-normal sm:text-6xl md:text-7xl text-foreground">
              Building websites & apps for immersive digital experiences.
            </h1>
            <p className="text-foreground/70 md:text-xl lg:text-2xl">
              We design, build & ship websites and apps that shape the future of your business.
            </p>
          </div>
          <div className="flex flex-col gap-4 sm:flex-row animate-in fade-in-0 slide-in-from-bottom-4 duration-1000 delay-200">
            <Button 
              asChild 
              size="lg" 
              className="bg-card text-primary border border-primary/20 hover:bg-accent shadow-md"
            >
              <Link href="mailto:ranagaurav687@gmail.com?subject=Project%20Inquiry">Let's talk</Link>
            </Button>
            <Button 
              asChild 
              size="lg" 
              className="shadow-md" /* Uses default (primary) variant: black bg, white text */
            >
              <Link href="/#pricing">Pricing</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
