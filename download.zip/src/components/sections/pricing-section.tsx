import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardDescription } from '@/components/ui/card';
import { 
  Figma, 
  Framer, 
  Sparkles, 
  SquareDot, 
  LoaderCircle, 
  CheckCircle2, 
  IterationCcw, 
  MessageCircle,
  LayoutGrid,
  PencilRuler,
  Layers3,
  Code,
  PlusCircle,
  Briefcase,
  Headphones
} from 'lucide-react';
import Link from 'next/link';

const EMAIL_ADDRESS = "ranagaurav687@gmail.com";

const mailto = (subject: string, body: string = "Hi, I'm interested in learning more.") => 
  `mailto:${EMAIL_ADDRESS}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

const landingPageFeatures = [
  { icon: CheckCircle2, text: "Single page" },
  { icon: PencilRuler, text: "Design only" },
  { icon: IterationCcw, text: "Multiple iterations" },
  { icon: MessageCircle, text: "Slack/Discord communication" },
];

const fullWebsiteFeatures = [
  { icon: LayoutGrid, text: "Multiple pages" },
  { icon: PencilRuler, text: "Design & build" },
  { icon: Layers3, text: "Components library" },
  { icon: Code, text: "Custom code" },
  { icon: IterationCcw, text: "Multiple iterations" },
  { icon: MessageCircle, text: "Slack/Discord communication" },
];

const customCardFeatures = [
  { icon: PlusCircle, text: "Web apps" },
  { icon: PlusCircle, text: "Desktop apps" },
  { icon: PlusCircle, text: "Mobile apps" },
];

export function PricingSection() {
  return (
    <section id="pricing" className="w-full py-12 md:py-24 lg:py-32 bg-background">
      <div className="container max-w-[1440px] px-4 sm:px-6 md:px-8 lg:px-16 xl:px-20">
        <div className="text-center mb-12 md:mb-16 animate-in fade-in-0 slide-in-from-bottom-2 duration-700">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-foreground">Pricing</h2>
          <p className="max-w-[700px] mx-auto text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed mt-4">
            Elevate your brand with our in-house design expert who brings over 12 years of experience to the table.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 items-stretch mb-12 md:mb-16">
          {/* Card 1: Landing Page */}
          <div 
            className="flex flex-col h-full space-y-6 md:space-y-8 animate-in fade-in-0 slide-in-from-bottom-5 duration-500"
            style={{ animationDelay: "100ms" }}
          >
            <Card className="bg-card text-card-foreground rounded-xl shadow-lg flex flex-col flex-grow p-6 md:p-8">
              <CardHeader className="p-0 mb-4">
                <div className="flex justify-between items-start mb-3">
                  <Figma className="h-8 w-8 text-foreground" />
                  <span className="text-xs text-muted-foreground font-medium">❖ contra</span>
                </div>
                <div className="flex items-center space-x-2 mb-3">
                  <Sparkles className="h-4 w-4 text-primary" />
                  <span className="text-xs bg-muted px-2 py-1 rounded-md font-medium text-foreground">Figma Project</span>
                </div>
                <div className="flex justify-between items-baseline">
                  <h3 className="text-2xl font-semibold text-foreground">Landing Page</h3>
                  <p className="text-2xl font-bold text-foreground">$6K</p>
                </div>
                <CardDescription className="text-sm text-muted-foreground !mt-2">
                  Capture attention and drive conversions effectively. Meticulously crafted design to impact your audience.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0 flex-grow space-y-2.5 text-sm">
                {landingPageFeatures.map((feature, idx) => (
                  <div key={idx} className="flex items-center">
                    <feature.icon className="h-4 w-4 mr-2.5 text-primary flex-shrink-0" /> 
                    <span className="text-muted-foreground">{feature.text}</span>
                  </div>
                ))}
              </CardContent>
              <CardFooter className="p-0 mt-6">
                <Button asChild className="w-full bg-primary text-primary-foreground hover:bg-primary/90 shadow-md">
                  <Link href={mailto("Inquiry: Landing Page Design Only", "Hi, I'm interested in the Landing Page Design package.")}>Choose Design Only</Link>
                </Button>
              </CardFooter>
            </Card>
            
            <Card className="bg-muted/60 text-card-foreground rounded-xl shadow-md p-6">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <Framer className="h-5 w-5 mr-2 text-foreground" />
                  <h4 className="font-semibold text-foreground text-md">Framer Development</h4>
                </div>
                <p className="font-bold text-foreground text-lg">+&#36;2K</p>
              </div>
              <p className="text-sm text-muted-foreground mb-4">For an additional fee, we offer the option to build your website in Framer and take it to its final, polished stage.</p>
              <Button asChild variant="outline" className="w-full bg-card hover:bg-accent border-border shadow-sm">
                <Link href={mailto("Inquiry: Landing Page Design + Development", "Hi, I'm interested in the Landing Page Design + Framer Development package.")}>Get Design + Development</Link>
              </Button>
            </Card>
          </div>

          {/* Card 2: Full Website */}
          <div 
            className="flex flex-col h-full space-y-6 md:space-y-8 animate-in fade-in-0 slide-in-from-bottom-5 duration-500"
            style={{ animationDelay: "250ms" }}
            >
            <Card className="bg-card text-card-foreground rounded-xl shadow-lg flex flex-col flex-grow p-6 md:p-8">
              <CardHeader className="p-0 mb-4">
                <div className="flex justify-between items-start mb-3">
                  <Framer className="h-8 w-8 text-foreground" />
                  <span className="text-xs text-muted-foreground font-medium">❖ contra</span>
                </div>
                <div className="flex items-center space-x-2 mb-3">
                  <SquareDot className="h-4 w-4 text-primary" />
                  <span className="text-xs bg-muted px-2 py-1 rounded-md font-medium text-foreground">Framer Build</span>
                </div>
                <div className="flex justify-between items-baseline">
                  <h3 className="text-2xl font-semibold text-foreground">Full Website</h3>
                  <p className="text-sm text-muted-foreground">Starting at <span className="text-2xl font-bold text-foreground">$12K+</span></p>
                </div>
                <CardDescription className="text-sm text-muted-foreground !mt-2">
                  Full scale business website with multiple pages, seamless CMS integration, SEO optimization and outstanding performance.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0 flex-grow space-y-2.5 text-sm">
                {fullWebsiteFeatures.map((feature, idx) => (
                  <div key={idx} className="flex items-center">
                    <feature.icon className="h-4 w-4 mr-2.5 text-primary flex-shrink-0" /> 
                     <span className="text-muted-foreground">{feature.text}</span>
                  </div>
                ))}
              </CardContent>
              <CardFooter className="p-0 mt-6">
                <Button asChild className="w-full bg-primary text-primary-foreground hover:bg-primary/90 shadow-md">
                  <Link href={mailto("Inquiry: Full Website", "Hi, I'm interested in the Full Website package.")}>Get Full Website</Link>
                </Button>
              </CardFooter>
            </Card>
            <div className="text-center text-sm text-muted-foreground p-4 bg-muted/60 rounded-xl shadow-sm">
                <div className="flex items-center justify-center">
                    <Framer className="h-5 w-5 mr-2 text-foreground" />
                    <p className="font-semibold text-foreground">Framer Development</p>
                </div>
                <p className="text-muted-foreground">Included</p>
             </div>
             <p className="text-xs text-muted-foreground text-center max-w-xs mx-auto">
                The price may vary depending on the total number of pages; current pricing covers ~ 4-5 pages.
             </p>
          </div>

          {/* Card 3: Custom */}
          <Card 
            className="bg-primary text-primary-foreground rounded-xl shadow-lg flex flex-col h-full p-6 md:p-8 animate-in fade-in-0 slide-in-from-bottom-5 duration-500"
            style={{ animationDelay: "400ms" }}
          >
            <CardHeader className="p-0 mb-4">
              <div className="flex justify-between items-start mb-3">
                <LoaderCircle className="h-8 w-8 text-primary-foreground" /> 
              </div>
              <div className="flex justify-between items-baseline mt-8 mb-3"> {/* Added mt for spacing */}
                <h3 className="text-2xl font-semibold">Custom</h3>
                <p className="text-sm text-primary-foreground/80">Starting at <span className="text-2xl font-bold text-primary-foreground">$20K+</span></p>
              </div>
              <CardDescription className="text-sm text-primary-foreground/80 !mt-2">
                Seeking a different scope of work? We're offering a variety of other design services.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0 flex-grow space-y-3 text-sm">
              <div className="bg-primary-foreground/10 p-3 rounded-md text-sm flex items-center">
                <PencilRuler className="h-4 w-4 mr-2 text-primary-foreground/80 flex-shrink-0" /> Figma workflow, no development.
              </div>
              {customCardFeatures.map((feature, idx) => (
                <div key={idx} className="flex items-center">
                  <feature.icon className="h-4 w-4 mr-2.5 text-primary-foreground/80 flex-shrink-0" /> 
                  {feature.text}
                </div>
              ))}
            </CardContent>
            <CardFooter className="p-0 mt-6">
              <Button asChild variant="outline" className="w-full bg-primary-foreground text-primary hover:bg-primary-foreground/90 shadow-md">
                <Link href={mailto("Inquiry: Custom Project", "Hi, I'm interested in a Custom project.")}>Request Quote</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 items-stretch">
          <Card 
            className="md:col-span-2 bg-card text-card-foreground rounded-xl shadow-lg p-6 md:p-8 flex flex-col sm:flex-row items-center justify-between animate-in fade-in-0 slide-in-from-bottom-5 duration-500"
            style={{ animationDelay: "550ms" }}
          >
            <div className="flex items-center mb-4 sm:mb-0">
              <Sparkles className="h-10 w-10 text-primary mr-4 flex-shrink-0" />
              <div className="text-center sm:text-left">
                <span className="text-xs bg-muted px-2 py-1 rounded-md font-medium text-foreground inline-block mb-1">FRAMER EXPERT</span>
                <h3 className="text-xl md:text-2xl font-semibold text-foreground">Hire on Contra</h3>
              </div>
            </div>
            <div className="flex-grow sm:flex-grow-0 text-center sm:text-left sm:ml-4 mt-2 sm:mt-0">
                 <p className="text-sm text-muted-foreground mb-4 sm:hidden">
                    Trusted by 20,000+ teams from creative agencies to high growth tech companies.
                </p>
                 <Button asChild className="bg-[hsl(221.2_83.2%_53.3%)] text-primary-foreground hover:bg-[hsl(221.2_83.2%_48.3%)] shadow-md whitespace-nowrap">
                    <Link href="https://contra.com" target="_blank" rel="noopener noreferrer">
                        <Briefcase className="h-4 w-4 mr-2" /> Hire on Contra
                    </Link>
                </Button>
            </div>
             <p className="text-sm text-muted-foreground mt-4 hidden sm:block md:max-w-xs lg:max-w-sm xl:max-w-md">
                Trusted by 20,000+ teams from creative agencies to high growth tech companies. This description appears below the button on larger screens due to layout constraints but is associated with the "Hire on Contra" card.
            </p>
          </Card>

          <Card 
            className="bg-primary text-primary-foreground rounded-xl shadow-lg p-6 md:p-8 flex flex-col justify-between animate-in fade-in-0 slide-in-from-bottom-5 duration-500"
            style={{ animationDelay: "700ms" }}
          >
            <div>
                <div className="flex items-center mb-3">
                <Headphones className="h-7 w-7 text-primary-foreground/80 mr-3" />
                <h3 className="text-xl md:text-2xl font-semibold">Can&apos;t decide? Let&apos;s talk</h3>
                </div>
                <p className="text-sm text-primary-foreground/80 mb-6">
                We&apos;re flexible, so if you don&apos;t feel like having a call we can take it async.
                </p>
            </div>
            <Button asChild className="w-full bg-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/30 border border-primary-foreground/30 shadow-sm">
              <Link href={mailto("General Inquiry: Let's Talk", "Hi, I'd like to discuss my project.")}>Send us an email</Link>
            </Button>
          </Card>
        </div>
      </div>
    </section>
  );
}
