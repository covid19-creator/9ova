import Link from 'next/link';

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-[1440px] items-center px-4 sm:px-6 md:px-8 lg:px-16 xl:px-20">
        <Link href="/" className="mr-6 flex items-center space-x-2">
          {/* Using a simple bold 'c' for the logo as per the design */}
          <span className="font-bold text-3xl text-foreground">c</span>
        </Link>
        {/* Future navigation items can go here */}
        {/* <nav className="flex items-center gap-4 text-sm lg:gap-6">
          <Link
            href="/#projects"
            className="text-foreground/60 transition-colors hover:text-foreground/80"
          >
            Projects
          </Link>
          <Link
            href="/#contact"
            className="text-foreground/60 transition-colors hover:text-foreground/80"
          >
            Contact
          </Link>
        </nav> */}
      </div>
    </header>
  );
}
